# Restaurante App — Semana 13

## Conceptos fundamentales de interfaces gráficas de usuario

Primera versión gráfica de **restaurante_app** con **Tkinter**, correspondiente a la
Semana 13 de Programación Orientada a Objetos. Es una base simplificada equivalente a la
estructura del proyecto docente *Biblioteca App*, adaptada al dominio de un restaurante
(Libro → Producto). Las demás funciones del restaurante se agregarán en semanas posteriores.

## Estructura

```
restaurante_app/
├── datos/
│   ├── productos.json
│   └── usuarios.json
├── modelos/
│   ├── __init__.py
│   ├── producto.py
│   └── usuario.py
├── servicios/
│   ├── __init__.py
│   ├── archivo_servicio.py
│   └── restaurante_servicio.py
├── ui/
│   ├── __init__.py
│   ├── login_view.py
│   └── main_view.py
└── main.py
```

## Responsabilidades

| Archivo | Responsabilidad |
|---|---|
| `modelos/producto.py`, `modelos/usuario.py` | Representan las entidades y se crean desde diccionarios. |
| `servicios/archivo_servicio.py` | Única clase que lee los archivos JSON. |
| `servicios/restaurante_servicio.py` | Recibe los datos cargados, los convierte en objetos y ofrece: validar acceso, listar usuarios, listar productos y consultar cantidades. |
| `ui/login_view.py` | Pantalla de acceso simulada (usuario, contraseña y mensajes). |
| `ui/main_view.py` | Panel principal con Productos, Usuarios y Ventas (pendiente). |
| `main.py` | Crea la única ventana `Tk()`, prepara los servicios, se los entrega a las vistas y controla el cambio entre ellas. |

Las vistas **no** leen archivos JSON: piden todo a `RestauranteServicio`.

## Flujo de la aplicación

```
main.py prepara Tkinter y los servicios
        ↓
LoginView → usuario y contraseña
        ↓
RestauranteServicio valida el acceso
        ↓
MainView → Productos | Usuarios | Ventas (pendiente)
        ↓
Cerrar sesión → LoginView
```

Ambas vistas son `Frame` dentro de la misma ventana; `main.py` las alterna con
`pack()` / `pack_forget()`, con una sola instancia de `Tk()` y un solo `mainloop()`.

## Vistas implementadas

- **LoginView:** mensajes para campos vacíos y credenciales incorrectas.
- **MainView:** tabla de productos (con cantidades y total de unidades), tabla de usuarios y opción **Ventas** marcada como funcionalidad pendiente.

## Ejecución

Requiere Python 3.10+ con Tkinter (en Linux: `sudo apt install python3-tk`).

```bash
cd restaurante_app
python main.py
```

Usuario de prueba: `admin` / `admin123` (también `mlopez`, `cruiz`, `dtorres`; ver `datos/usuarios.json`).

> El acceso es una **simulación pedagógica**: no representa un sistema real de autenticación segura.
