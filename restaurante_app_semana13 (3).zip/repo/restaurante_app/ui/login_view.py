"""
LoginView: pantalla de acceso simulada. Recoge usuario y contrasena y pide
la validacion a RestauranteServicio; no conoce los archivos JSON.
"""

import tkinter as tk
from tkinter import ttk

COLOR_FONDO = "#1f2a38"
COLOR_ERROR = "#b22234"


class LoginView(tk.Frame):
    def __init__(self, padre, servicio, al_ingresar):
        super().__init__(padre, bg=COLOR_FONDO)
        self.servicio = servicio
        self.al_ingresar = al_ingresar  # funcion de main.py para abrir MainView
        self._construir()

    def _construir(self):
        centro = tk.Frame(self, bg=COLOR_FONDO)
        centro.place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(centro, text="Restaurante App", font=("Segoe UI", 24, "bold"),
                 fg="white", bg=COLOR_FONDO).pack()
        tk.Label(centro, text="Acceso al sistema (simulado)", font=("Segoe UI", 10),
                 fg="#c9d1d9", bg=COLOR_FONDO).pack(pady=(0, 20))

        tarjeta = tk.Frame(centro, bg="white", padx=30, pady=25)
        tarjeta.pack()

        tk.Label(tarjeta, text="Usuario", bg="white", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.entrada_usuario = ttk.Entry(tarjeta, width=30)
        self.entrada_usuario.pack(pady=(2, 12))

        tk.Label(tarjeta, text="Contrasena", bg="white", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.entrada_clave = ttk.Entry(tarjeta, width=30, show="*")
        self.entrada_clave.pack(pady=(2, 8))

        self.etiqueta_mensaje = tk.Label(tarjeta, text="", fg=COLOR_ERROR, bg="white",
                                         font=("Segoe UI", 9))
        self.etiqueta_mensaje.pack(pady=(0, 8))

        ttk.Button(tarjeta, text="Ingresar", command=self.intentar_ingreso).pack(fill="x")

        tk.Label(centro, text="Usuario de prueba: admin / admin123",
                 fg="#8b949e", bg=COLOR_FONDO, font=("Segoe UI", 8)).pack(pady=12)

    def intentar_ingreso(self):
        usuario = self.entrada_usuario.get().strip()
        clave = self.entrada_clave.get().strip()

        if not usuario or not clave:
            self.etiqueta_mensaje.config(text="Ingrese usuario y contrasena.")
            return

        usuario_valido = self.servicio.validar_acceso(usuario, clave)
        if usuario_valido is None:
            self.etiqueta_mensaje.config(text="Usuario o contrasena incorrectos.")
            return

        self.limpiar()
        self.al_ingresar(usuario_valido)

    def limpiar(self):
        self.entrada_usuario.delete(0, "end")
        self.entrada_clave.delete(0, "end")
        self.etiqueta_mensaje.config(text="")
        self.entrada_usuario.focus()
