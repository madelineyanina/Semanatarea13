"""
MainView: panel principal tras un acceso correcto. Muestra productos y
usuarios pidiendo los datos a RestauranteServicio. Ventas queda como
funcionalidad pendiente para semanas posteriores.
"""

import tkinter as tk
from tkinter import ttk

COLOR_BARRA = "#1f2a38"
COLOR_FONDO = "#f4f6f8"
COLOR_ACENTO = "#b22234"


class MainView(tk.Frame):
    def __init__(self, padre, servicio, al_cerrar_sesion):
        super().__init__(padre, bg=COLOR_FONDO)
        self.servicio = servicio
        self.al_cerrar_sesion = al_cerrar_sesion  # funcion de main.py para volver al login
        self._construir()

    def _construir(self):
        barra = tk.Frame(self, bg=COLOR_BARRA, width=200)
        barra.pack(side="left", fill="y")
        barra.pack_propagate(False)

        tk.Label(barra, text="Restaurante App", bg=COLOR_BARRA, fg="white",
                 font=("Segoe UI", 13, "bold")).pack(pady=(25, 5))
        self.etiqueta_sesion = tk.Label(barra, text="", bg=COLOR_BARRA, fg="#c9d1d9",
                                        font=("Segoe UI", 9), justify="center")
        self.etiqueta_sesion.pack(pady=(0, 20))

        self._boton(barra, "Productos", self.mostrar_productos)
        self._boton(barra, "Usuarios", self.mostrar_usuarios)
        self._boton(barra, "Ventas (pendiente)", self.mostrar_ventas)

        tk.Frame(barra, bg=COLOR_BARRA).pack(expand=True, fill="both")
        self._boton(barra, "Cerrar sesion", self.al_cerrar_sesion)

        self.contenido = tk.Frame(self, bg=COLOR_FONDO)
        self.contenido.pack(side="right", expand=True, fill="both", padx=25, pady=20)

    def _boton(self, padre, texto, comando):
        tk.Button(padre, text=texto, command=comando, bg=COLOR_BARRA, fg="white",
                  activebackground=COLOR_ACENTO, activeforeground="white", bd=0,
                  font=("Segoe UI", 10), pady=10).pack(fill="x", padx=10, pady=3)

    def iniciar_sesion(self, usuario):
        """Llamado por main.py cuando el acceso fue correcto."""
        self.etiqueta_sesion.config(text=f"{usuario.nombre}\n({usuario.rol})")
        self.mostrar_productos()

    def _limpiar(self):
        for widget in self.contenido.winfo_children():
            widget.destroy()

    def _encabezado(self, titulo, resumen):
        tk.Label(self.contenido, text=titulo, font=("Segoe UI", 16, "bold"),
                 bg=COLOR_FONDO, fg=COLOR_BARRA).pack(anchor="w")
        tk.Label(self.contenido, text=resumen, font=("Segoe UI", 10),
                 bg=COLOR_FONDO, fg="#555").pack(anchor="w", pady=(0, 12))

    def _tabla(self, columnas):
        tabla = ttk.Treeview(self.contenido, columns=[c[0] for c in columnas],
                             show="headings", height=15)
        for clave, titulo, ancho in columnas:
            tabla.heading(clave, text=titulo)
            tabla.column(clave, width=ancho)
        tabla.pack(fill="both", expand=True)
        return tabla

    def mostrar_productos(self):
        self._limpiar()
        self._encabezado(
            "Productos registrados",
            f"{self.servicio.contar_productos()} productos - "
            f"{self.servicio.total_unidades_disponibles()} unidades disponibles",
        )
        tabla = self._tabla([("nombre", "Producto", 280), ("categoria", "Categoria", 140),
                             ("precio", "Precio ($)", 90), ("stock", "Cantidad", 90)])
        for p in self.servicio.listar_productos():
            tabla.insert("", "end", values=(p.nombre, p.categoria, f"{p.precio:.2f}", p.stock))

    def mostrar_usuarios(self):
        self._limpiar()
        self._encabezado("Usuarios registrados",
                         f"{self.servicio.contar_usuarios()} usuarios en el sistema")
        tabla = self._tabla([("nombre", "Nombre", 260), ("usuario", "Usuario", 140),
                             ("rol", "Rol", 140)])
        for u in self.servicio.listar_usuarios():
            tabla.insert("", "end", values=(u.nombre, u.usuario, u.rol))

    def mostrar_ventas(self):
        self._limpiar()
        self._encabezado("Ventas", "Funcionalidad pendiente")
        tk.Label(self.contenido, text="La gestion de ventas se incorporara en una etapa posterior.",
                 bg=COLOR_FONDO, fg="#555", font=("Segoe UI", 11)).pack(pady=40)
