"""
ArchivoServicio: unica responsabilidad, leer los datos locales en archivos JSON.
Ni las vistas ni los modelos leen archivos directamente.
"""

import json
import os


class ArchivoServicio:
    def __init__(self, carpeta_datos):
        self.carpeta_datos = carpeta_datos

    def leer_json(self, nombre_archivo):
        """Devuelve la lista almacenada en el JSON, o [] si falta o esta danado."""
        ruta = os.path.join(self.carpeta_datos, nombre_archivo)
        try:
            with open(ruta, "r", encoding="utf-8") as archivo:
                return json.load(archivo)
        except (FileNotFoundError, json.JSONDecodeError):
            return []
