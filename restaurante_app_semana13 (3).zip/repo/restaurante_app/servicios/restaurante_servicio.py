"""
RestauranteServicio: recibe los datos ya cargados, los convierte en objetos
y ofrece las operaciones que usan las vistas: validar acceso, listar
usuarios, listar productos y consultar cantidades.
"""

from modelos.producto import Producto
from modelos.usuario import Usuario


class RestauranteServicio:
    def __init__(self, datos_usuarios, datos_productos):
        self._usuarios = [Usuario.desde_diccionario(d) for d in datos_usuarios]
        self._productos = [Producto.desde_diccionario(d) for d in datos_productos]

    def validar_acceso(self, usuario, clave):
        """Devuelve el Usuario si las credenciales son correctas; si no, None."""
        for u in self._usuarios:
            if u.usuario == usuario and u.clave == clave:
                return u
        return None

    def listar_usuarios(self):
        return list(self._usuarios)

    def listar_productos(self):
        return list(self._productos)

    def contar_usuarios(self):
        return len(self._usuarios)

    def contar_productos(self):
        return len(self._productos)

    def total_unidades_disponibles(self):
        """Suma de las unidades en stock de todos los productos."""
        return sum(p.stock for p in self._productos)
