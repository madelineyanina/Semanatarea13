"""
main.py: punto de entrada.
Crea la unica ventana Tk, prepara los servicios, entrega esas dependencias
a las vistas y controla el cambio entre LoginView y MainView.
"""

import os
import tkinter as tk

from servicios.archivo_servicio import ArchivoServicio
from servicios.restaurante_servicio import RestauranteServicio
from ui.login_view import LoginView
from ui.main_view import MainView

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


class Aplicacion:
    def __init__(self):
        # Una sola ventana principal y un solo mainloop
        self.ventana = tk.Tk()
        self.ventana.title("Restaurante App")
        self.ventana.geometry("900x560")
        self.ventana.minsize(800, 500)

        # Preparacion de servicios
        archivos = ArchivoServicio(os.path.join(BASE_DIR, "datos"))
        self.servicio = RestauranteServicio(
            archivos.leer_json("usuarios.json"),
            archivos.leer_json("productos.json"),
        )

        # Vistas: ambas viven en la misma ventana y se alternan
        self.login_view = LoginView(self.ventana, self.servicio, self.mostrar_principal)
        self.main_view = MainView(self.ventana, self.servicio, self.cerrar_sesion)

        self.mostrar_login()

    def mostrar_login(self):
        self.main_view.pack_forget()
        self.login_view.pack(expand=True, fill="both")

    def mostrar_principal(self, usuario):
        self.login_view.pack_forget()
        self.main_view.iniciar_sesion(usuario)
        self.main_view.pack(expand=True, fill="both")

    def cerrar_sesion(self):
        self.mostrar_login()

    def ejecutar(self):
        self.ventana.mainloop()


if __name__ == "__main__":
    Aplicacion().ejecutar()
