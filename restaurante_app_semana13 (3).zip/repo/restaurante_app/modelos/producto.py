"""Modelo Producto: representa un producto del menu del restaurante."""


class Producto:
    def __init__(self, id, nombre, categoria, precio, stock):
        self.id = id
        self.nombre = nombre
        self.categoria = categoria
        self.precio = precio
        self.stock = stock

    @staticmethod
    def desde_diccionario(datos):
        """Crea un Producto a partir de un diccionario cargado desde JSON."""
        return Producto(
            datos["id"], datos["nombre"], datos["categoria"], datos["precio"], datos["stock"]
        )

    def __str__(self):
        return f"{self.nombre} - ${self.precio:.2f}"
