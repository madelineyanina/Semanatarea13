"""Modelo Usuario: representa a un usuario usado en la simulacion de acceso."""


class Usuario:
    def __init__(self, id, nombre, usuario, clave, rol):
        self.id = id
        self.nombre = nombre
        self.usuario = usuario
        self.clave = clave
        self.rol = rol

    @staticmethod
    def desde_diccionario(datos):
        """Crea un Usuario a partir de un diccionario cargado desde JSON."""
        return Usuario(
            datos["id"], datos["nombre"], datos["usuario"], datos["clave"], datos["rol"]
        )

    def __str__(self):
        return f"{self.nombre} ({self.rol})"
